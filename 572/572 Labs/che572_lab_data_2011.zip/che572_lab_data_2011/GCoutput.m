% Calibration Data for Team 1

%   Team 1 March 24    Team 1 March 31
T =[66.9941666666667    68.44;   %Tray 1
    68.275              69.69;   %Tray 2
    68.7591666666667    70.14;   %Tray 3
    70.12083333         72.12;   %Tray 4
    71.63833333         74.44;   %Tray 5
    73.44916667         76.12;   %Reboiler
    30.2025             32.75;   %Feed
    0                   66.06];   %Top Product out (Condenser)
% Note that we did not collect the temperature for the top product on March
% 24th!

% Weight fraction of methanol (same order/format as above)
X =[0.63 0.53747310694000;    %Tray 1
    0.56 0.462874330365400;    %Tray 2
    0.51 0.435789190998400;    %Tray 3
    0.46 0.351698832885400;    %Tray 4
    0.39 0.267269932828150;    %Tray 5
    0.29 0.194951958683350;    %Reboiler
    0.54 0.543416275048600;    %Feed
    0.76,0.677579236149600;];  %Top Product out (Condenser)